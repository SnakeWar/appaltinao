import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app.module';

// import { myRouterProviders } from './app.router';

platformBrowserDynamic().bootstrapModule(AppModule);

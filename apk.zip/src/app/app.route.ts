// /**
//  * Created by Mayrc on 01/08/2017.
//  */
// import { providerRouter, RouterConfig } from '@angular/router';
// import { InicialPage } from '../pages/inicial/inicial';
//
// const routes: RouterConfig = [
//     { path: 'iniciar', component: InicialPage}
// ];
//
// export const myRouterProviders = [
//     providerRouter(routes)
// ];